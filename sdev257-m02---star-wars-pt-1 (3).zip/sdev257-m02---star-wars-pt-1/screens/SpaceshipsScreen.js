import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, SafeAreaView, } from 'react-native';

export default function SpaceshipsScreen() {
  const [starships, setStarships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchStarships();
  }, []);

  const fetchStarships = async () => {
    try {
      const response = await fetch('https://swapi.dev/api/starships/');
      const data = await response.json();
      setStarships(data.results);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatCredits = (credits) => {
    if (credits === 'unknown' || !credits) return 'unknown';
    return Number(credits).toLocaleString();
  }

  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.detail}>Model: {item.model}</Text>
      <Text style={styles.detail}>Manufacturer date: {item.manufacturer}</Text>
      <Text style={styles.detail}>Cost: {formatCredits(item.cost_in_credits)} credits</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#FFE81F" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.centered}>
        <Text style={styles.errorText}>Error: {error}</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={starships}
        keyExtractor={(item) => item.name}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#000',
  },
  list: {
    padding: 16,
  },
  itemContainer: {
    backgroundColor: '#1a1a1a',
    padding: 16,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FFE81F',
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFE81F',
    marginBottom: 8,
  },
  detail: {
    fontSize: 14,
    color: '#ddd',
    marginBottom: 4,
  },
  errorText: {
    color: '#FFE81F',
    fontSize: 16,
  },
});